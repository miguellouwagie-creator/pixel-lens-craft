# Installation
> `npm install --save @types/phoenix`

# Summary
This package contains type definitions for phoenix (https://github.com/phoenixframework/phoenix).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/phoenix.

### Additional Details
 * Last updated: Mon, 25 Nov 2024 04:36:43 GMT
 * Dependencies: none

# Credits
These definitions were written by [Mirosław Ciastek](https://github.com/mciastek), [John Goff](https://github.com/John-Goff), and [Po Chen](https://github.com/princemaple).
